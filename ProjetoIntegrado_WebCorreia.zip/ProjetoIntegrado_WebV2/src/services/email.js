const nodemailer = require('nodemailer');

const sendWelcomeEmail = (email) => {
    const  transporter = nodemailer.createTransport({
        service: 'Hotmail',
          auth: {
            user: 'registobasedados@outlook.pt',
            pass: 'softsinsa331'
          }
      });
      
      const emailOptions = {
        from: 'registobasedados@outlook.pt',
        to: email,
        subject: 'Registo na Base de Dados',
        html: `<h1>Foi registrado na Base de Dados Softinsa</h1>
        
        <p>Credenciais de acesso</p>
        <p>Email: ${email}</p>
        <p>Password: 1234</p>`

      
      }
      transporter.sendMail(emailOptions, (err, result)=>{
        if(err)
           return console.log(err)
        console.log('Mensagem enviada!' + result)
      })
}

module.exports = {
    sendWelcomeEmail
}