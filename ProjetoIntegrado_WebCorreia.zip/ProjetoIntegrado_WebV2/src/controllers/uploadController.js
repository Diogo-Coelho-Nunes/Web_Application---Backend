var sequelize = require("../model/database");
const { parse } = require("csv-parse");
const Utilizador = require("../model/Utilizadores");
const { sendWelcomeEmail } = require("../services/email");

const controllers = {};

controllers.utilizadores = async (req, res) => {
  console.log(req.files);
  parse(
    req.files.file.data,
    {
      delimiter: ";",
      columns: true,
      trim: true,
      ignore_last_delimiters: true,
      bom: true,
    },
    async (err, records) => {
      const filteredrecords = records.filter((r) => r.NIF != "");
      filteredrecords.forEach((record) => sendWelcomeEmail(record.Email));
      console.log(filteredrecords);

      await Utilizador.bulkCreate(filteredrecords);
      res.sendStatus(200);
    }
  );
};

module.exports = controllers;
