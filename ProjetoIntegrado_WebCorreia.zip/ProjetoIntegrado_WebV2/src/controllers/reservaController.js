var Reserva = require('../model/Reserva');
var sequelize = require('../model/database');
var Sala = require ('../model/Sala');
var Utilizadores = require('../model/Utilizadores');
const {QueryTypes} = require('sequelize');
const controllers = {}

controllers.testedata = async(req,res)=>{
    const response = await sequelize.sync().then(function() {
        //Criar Reserva para teste
        Reserva.create({
            Data_Reserva: '2022-03-17',
            Hora_Inicio: '9:00',
            Hora_Fim: '9:30',
            N_Participantes: 10,
            N_Funcionario: 2,
            N_Sala: 1,
            Titulo_Reserva: 'Reunião c/ chefe'

        });
        const data = Reserva.findAll()
        return data;
    })
    .catch(err => {
        return err;
    });
    res.json(response)
}

controllers.list = async (req,res) => {
    const data = await Reserva.findAll({
        include: [Utilizadores,Sala]
    })
    .then(function(data){
        return data;
    })
    .catch(error =>{
        return error;
    });
    res.json({success: true, data: data});
}

controllers.get = async (req,res) => {
    const {N_Reserva} = req.params;
    const data = await Reserva.findAll({
        where: {N_Reserva: N_Reserva},
        include: [Utilizadores,Sala]

    })
    .then(function(data){
        return data;
    })
    .catch(error =>{
        return error;
    })
    res.json({ success: true, data: data });
}

controllers.update = async (req,res) => {
    const {N_Reserva} = req.params;
    const {Data_Reserva,N_Participantes,Hora_Inicio,Hora_Fim} = req.body;
    const data = await Reserva.update({
        Data_Reserva: Data_Reserva,
        N_Participantes: N_Participantes,
        Hora_Inicio: Hora_Inicio,
        Hora_Fim: Hora_Fim
    },
    {
        where: {N_Reserva: N_Reserva}
    })
    .then( function(data){
        return data;
    })
    .catch(error => {
        return error;
    })
    res.json({success:true, data:data, message:"Updated successful"});
}

//% de alocação diária, com visão mensal
controllers.ChartAlocDiaria = async (req, res) => {
    const {N_centro, Data} = req.body;
    const Mes = new Date(Data)
    const Mes_Fim = new Date(data.setMonth(data.getMonth()+1))
    const data = await Reserva.findAll({
        where: {
            Data_Reserva: {
                [Op.gte]: Mes,
                [Op.lt]: Mes_Fim
            },
            N_centro: N_centro
        }
    })
    .then( function(data){
        return data;
    })
    .catch(error => {
        return error;
    })
    res.json({success:true, data:data});
    
    
}

//# reservas por range de datas
controllers.ChartReservasDatas = async (req,res) => {
    const {Data_Inicio, Data_Fim} = req.body;

    const data = await Reserva.findAndCountAll({
        where: { Data_Reserva: { 
                    [Op.gte]: Data_Inicio,
                    [Op.lte]: Data_Fim,
        }
        }
    })
    console.log(data.count)
    res.json(data.count)
}

controllers.create = async (req,res) => {
    const reserva = {Data_Reserva,Hora_Inicio,Hora_Fim,N_Participantes,Titulo_Reserva,N_Funcionario,N_Sala} = req.body;
    const sql = `INSERT into reservas ("Data_Reserva","Hora_Inicio","Hora_Fim","N_Participantes","Titulo_Reserva","N_Funcionario","N_Sala") 
    values('${reserva.Data_Reserva}','${reserva.Hora_Inicio}','${reserva.Hora_Fim}',${reserva.N_Participantes},'${reserva.Titulo_Reserva}',${reserva.N_Funcionario},${reserva.N_Sala})`
    await sequelize.query(sql,{type: QueryTypes.INSERT})
    .then(function(data) {
        res.json({
            success: true,
            message:"Reserva Criada",
            data: data
        });
    })
    .catch(error => {
        console.log("Erro: "+error)
        return error;
    })    
}

controllers.delete = async (req, res) => {
    const {N_Reserva} = req.params;
    const del = await Reserva.destroy({
        where: {
            N_Reserva: N_Reserva
        }
    })
    res.json({success:true,
        deleted:del,
        message:"Deleted successful"
    });
}

controllers.deletePastReserva = async (req, res) => {
    const {ID_Funcao,N_Reserva} = req.params;
    const {Data_Reserva} = req.body;
    const del = await Reserva.destroy({
        where: {
            Data_Reserva: {
                [Op.lt]: Data_Reserva,
            },
            ID_Funcao: ID_Funcao,
            N_Reserva : N_Reserva,
        }
    })
    res.json({success:true,
        deleted:del,
        message:"Deleted successful"
    });
}

controllers.listMobile = async (req,res) => {
    const{N_Utilizador} = req.params;
    const data = await Reserva.findAll({
        where:{N_Funcionario: N_Utilizador},
        include: [Utilizadores,Sala]
    })
    .then(function(data){
        return data;
    })
    .catch(error =>{
        return error;
    });
    res.json({success: true, data: data});
}

controllers.listMobileReservasAtuaisFuturas = async (req,res) => {
    const{N_Utilizador} = req.params;
    const data3 = await sequelize.query(`SELECT *
    FROM reservas, salas
    where "reservas"."Data_Reserva" >= now() and "reservas"."N_Funcionario" = :N_Utilizador and reservas."N_Sala" = salas."N_Sala"`,
    {replacements: {N_Utilizador: N_Utilizador}}
    )
    .then(function(data){
        return data[0];
    })
    .catch(error =>{
        return error;
    });
    res.json({success: true, data: data3});
}

controllers.getMobile = async (req,res) => {
    const {N_Sala} = req.params;
    const data = await Reserva.findAll({
        where: {N_Sala: N_Sala},
        include: [Utilizadores,Sala]

    })
    .then(function(data){
        return data;
    })
    .catch(error =>{
        return error;
    })
    res.json({ success: true, data: data });
}





module.exports = controllers