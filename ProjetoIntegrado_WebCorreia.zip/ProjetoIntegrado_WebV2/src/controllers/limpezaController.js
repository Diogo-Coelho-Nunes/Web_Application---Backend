var sequelize = require('../model/database');
var Limpeza = require('../model/Limpeza');

const controllers = {}

controllers.testedata = async(req,res)=>{
    const response = await sequelize.sync().then(function() {
        //Criar Limpeza
        Limpeza.create({
            Data_Limpeza: '2022-03-17',
            Hora_Inicio: '9:30',
            Hora_Fim: '9:36',
            N_Sala: 2,
            N_Utilizador: 1
        });
        const data = Limpeza.findAll()
        return data;
    })
    .catch(err => {
        return err;
    });
    res.json(response)
}

module.exports = controllers