var Utilizador = require('../model/Utilizadores');
var Funcao = require('../model/Funcao');
var sequelize = require('../model/database');

const controllers = {}

controllers.testedata = async(req,res) => {
    const response = await sequelize.sync().then(function() {
        //Criar Função
        Funcao.create({
            ID_Funcao: 1,
            Descricao: 'Admin'
        });
        Funcao.create ({
            ID_Funcao: 2,
            Descricao: 'Funcionario'
        });
        Funcao.create ({
            ID_Funcao: 3,
            Descricao: 'Limpeza'
        });
        const data = Funcao.findAll()
        return data;
    })
    .catch(err => {
        return err;
    });
    res.json(response)
}

controllers.list = async(req, res) => {
    const data = await Funcao.findAll({
    })
    .then(function(data){
        return data;
    })
    .catch(error =>{
        return error;
    });
    res.json({success: true, data: data});
}

module.exports = controllers