var Sequelize = require('sequelize');
var sequelize = require('./database');
const Sala = require('./Sala');
const Utilizador = require('./Utilizadores');



var Limpeza = sequelize.define ('limpeza', {
    Data_Limpeza:{
        type: Sequelize.DATE,
        allowNull: false
    },
    Hora_Inicio:{
        type: Sequelize.TIME,
        allowNull: false
    },
    Hora_Fim:{
        type: Sequelize.TIME,
        allowNull: false
    }  
    },
    {
        timestamps: false,
});

Limpeza.belongsTo(Sala, {foreignKey:{name: 'N_Sala'}});
Limpeza.belongsTo(Utilizador, {foreignKey: {name: 'N_Utilizador'}});


module.exports = Limpeza