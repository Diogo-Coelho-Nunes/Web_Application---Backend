var Sequelize = require('sequelize');
const Centro = require('./Centro');
var sequelize = require('./database');
const Funcao = require('./Funcao');
var bcrypt = require('bcryptjs');
var salt = bcrypt.genSaltSync(10);



var Utilizador = sequelize.define('utilizador', {
    N_Utilizador: {
        primaryKey: true,
        type: Sequelize.INTEGER,
        autoIncrement: true,
    },
    NIF: {
        type: Sequelize.INTEGER,
        allowNull: false,
        validate:{
            min: 100000000,
            max: 999999999
        }        

    },
    Nome_Utilizador: {
        type: Sequelize.STRING,
        allowNull: false
    },
    Morada: {
        type: Sequelize.STRING,
        allowNull: false

    },
    Codigo_Postal: {
        type: Sequelize.STRING,
        allowNull: false

    },
    N_telemovel: {
        type: Sequelize.STRING,
        allowNull: false
    },
    Email: {
        type: Sequelize.STRING,
        allowNull: false

    },
    Password:{
        type: Sequelize.STRING,
        allowNull: false,
        defaultValue: bcrypt.hashSync("1234", salt),
    },
    Verificado: {
        type: Sequelize.STRING,
        allowNull: false,
        validete:{
            is: 'R',
            is: 'N'
        },
        defaultValue: 'N'
          
    }
    },
    {
    timestamps: false,

});

Utilizador.belongsTo(Funcao, {foreignKey: {name: 'ID_Funcao'}});


module.exports = Utilizador