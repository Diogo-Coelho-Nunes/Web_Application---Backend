var Sequelize = require('sequelize');
var sequelize = require('./database');
var Centro = require('./Centro');


var Sala = sequelize.define('sala',{

    N_Sala: {
        primaryKey: true,
        type: Sequelize.INTEGER,
        autoIncrement: true,
    },
    Nome_Sala: {
       type: Sequelize.STRING,
       allowNull: false
    },
    Lugares: {
        type: Sequelize.INTEGER,
        allowNull: false
    },
    Lotacao_maxima: {
        type: Sequelize.INTEGER,
        allowNull: false
    },
    Tempo_Limpeza: {
        type: Sequelize.TIME,
        validete:{
            is: '00:05'
        },
        defaultValue: '00:05',
        allowNull: false
    },
    Disponibilidade:{
         type: Sequelize.STRING,
         validete:{
             is: 'O',
             is: 'L'
         },
         defaultValue: 'L'
    }
    },
    {
    timestamps: false,

});
Sala.belongsTo(Centro, { foreignKey: { name: 'N_centro'}});

module.exports = Sala