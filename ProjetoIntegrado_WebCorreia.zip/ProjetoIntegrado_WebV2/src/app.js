const express = require('express');
const app = express();
const centroRouters = require('./routes/centroRoute');
const salaRouters = require('./routes/salaRoute');
const utilizadorRouters = require('./routes/utilizadorRoute');
const funcaoRouters = require('./routes/funcaoRoute');
const reservaRouters = require('./routes/reservaRoute');
const limpezaRouters = require('./routes/limpezaRoute');
const uploadRouters = require('./routes/uploadRoute');
const middleware = require('./middleware');
const bodyParser = require('body-parser');
var cors = require('cors');



//Config
app.set('port',process.env.PORT || 4000);

//Midleware
app.use(express.json());

//CORS
app.use(cors());

//adicionei ate line 43
app.use(function (req, res, next) {

    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', '*');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);

    // Pass to next layer of middleware
    next();
});

//bodyParser usado para req.body
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended: true}))

//Rotas
app.use('/centro',centroRouters);

app.use('/sala',salaRouters);

app.use('/utilizador',utilizadorRouters);

app.use('/funcao',funcaoRouters);

app.use('/reserva', reservaRouters);

app.use('/limpeza', limpezaRouters);

app.use('/utilizador', middleware.checkToken,utilizadorRouters);

app.use('/upload', uploadRouters)



app.listen(app.get('port'),()=>{
    console.log("Servidor inicializado na porta "+app.get('port'))
})

//git teste