module.exports = {
    jwtSecret: 'chaveLogin'
};