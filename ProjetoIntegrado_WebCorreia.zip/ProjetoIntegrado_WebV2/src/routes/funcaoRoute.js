const express =  require('express');
const router = express.Router();

const funcaoController = require('../controllers/funcaoController');
const Funcao = require('../model/Funcao');

router.get('/testedata',funcaoController.testedata);
router.get('/list',funcaoController.list);


module.exports = router