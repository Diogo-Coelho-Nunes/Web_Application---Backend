const express =  require('express');
const router = express.Router();

const limpezaController = require('../controllers/limpezaController');
const { route } = require('./centroRoute');

router.get('/testedata', limpezaController.testedata);

module.exports = router