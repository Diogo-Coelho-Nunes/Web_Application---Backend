import React, { useEffect, useState } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { BrowserRouter as Router, Route, Link, Routes } from "react-router-dom";
import Centros from './view/centros';
import Salas from './view/salas';
import Utilizadores from './view/utilizadores';
import Inicio from './view/inicio';
import '../src/css/main.css';
import LogOutButton from "./view/logoutbutton";
import { useGetCurrentUser } from "./view/login";





function App() {
    const getCurrentUser = () => {
        const utilizadorgravado = localStorage.getItem("utilizador");
        if (utilizadorgravado) {
            console.log(utilizadorgravado)
          return JSON.parse(utilizadorgravado);
        } else {
          return null;
        }
      };
    
      const [currentUser, setcurrentUser] = useState("");
      useEffect(() => {
        const utilizador = getCurrentUser();
        if (utilizador) {
          setcurrentUser(utilizador);
        }
      }, []);
  
return (
    <Router>
      <nav className="navbar navbar-expand-lg navbar navbar-dark bg-dark">
        &nbsp; &nbsp;
        <a
          className="navbar-brand"
          style={{ color: "lightblue", fontWeight: "bold" }}
        >
          Softinsa
        </a>
        <button
          className="navbar-toggler"
          type="button"
          datatoggle="collapse"
          data-target="#navbarSupportedContent"
          ariacontrols="navbarSupportedContent"
          aria-expanded="false"
          arialabel="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        {currentUser ? (
          <div
            className="collapse navbar-collapse menu"
            id="navbarSupportedContent"
          >
            <Link className="nav-link" to="/centros">
              {" "}
              Centros{" "}
            </Link>
            &nbsp;&nbsp;
            <Link className="nav-link" to="/salas">
              {" "}
              Salas{" "}
            </Link>
            &nbsp;&nbsp;
            <Link className="nav-link" to="/utilizadores">
              {" "}
              Utilizadores{" "}
            </Link>
            &nbsp;&nbsp;
          </div>
        ):( <div
            className="collapse navbar-collapse menu"
            id="navbarSupportedContent"
          ></div>)}
      {currentUser && <LogOutButton removeUser={() => setcurrentUser(null)}/>}
      </nav>

      <Routes>
        <Route path="/" element={<Inicio addUser={(user) => setcurrentUser(user)}/>} />
        <Route path="/centros" element={<Centros />} />
        <Route path="/salas" element={<Salas />} />
        <Route path="/utilizadores" element={<Utilizadores />} />
      </Routes>
    </Router>
  );
}


export default App;
