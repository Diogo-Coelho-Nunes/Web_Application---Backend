import React, { useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import '../css/centros.css';
import InfoModal from './centroinfomodal';
import EditModal from './centroeditmodal';
import AddModal from './centroaddmodal';
import axios from 'axios';
import { useRedirectLogin } from './login';

export default function ListComponent() {

  const [centros, setCentros] = React.useState([])
  const [showInfoModal, setShowInfoModal] = React.useState(false)
  const [showEditModal, setShowEditModal] = React.useState(false)
  const [showAddModal, setShowAddModal] = React.useState(false)
  const [centroSelecionado, setCentroSelecionado] = React.useState()
  useRedirectLogin();
  useEffect(() => {
    const url = 'https://damp-badlands-24768.herokuapp.com/centro/list'

    axios.get(url)
    .then(res => {
      if (res.data.success) {
        const data = res.data.data;
        setCentros(data)
      } else {
        console.log('Erro a ir buscar data');
      }
    }).catch(error => {
      console.error(error)
    });
  }, [])

  const abrirInfoCentro = (centro) => {
    setCentroSelecionado(centro)
    setShowInfoModal(true)
  }

  const abrirEditCentro = (centro) => {
    setCentroSelecionado(centro)
    setShowEditModal(true)
  }

  const abrirAddCentro = (centro) => {
    setShowAddModal(true)
  }

  const deleteCentro = centro => {
    const url = 'https://damp-badlands-24768.herokuapp.com/centro/delete'

    axios.post(url, {
      N_centro: centro.N_centro
    }).then(res => {
      if (res.data.success) {
        setCentros(centros.filter(c => c.N_centro != centro.N_centro))
      } else {
        console.log('Erro a ir buscar data');
      }
    }).catch(error => {
      console.error(error)
    });
  }

  return (
    <body>
      <div className="bg-light clearfix">
        <button onClick={() => abrirAddCentro()} type="button" className="dw btn btn-primary">Adicionar</button>
      </div>
      <div className="album py-5 bg-light">
        <div className="container">
          <div className="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
            {centros.map(centro => {
              return (
                <div className="col">
                  <div className="card shadow-sm">
                    <img src="imagens/Hero-WillisTower.webp" />
                    <div className="card-body">
                      <p className="card-text">{centro.Nome_Centro}</p>
                      <div className="d-flex justify-content-between align-items-center">
                        <div className="btn-group">
                          <button onClick={() => abrirInfoCentro(centro)} type="button" class="btn btn-primary">Informações</button>
                          <button onClick={() => abrirEditCentro(centro)}type="button" class="btn btn-dark">Editar</button>
                          <button onClick={() => deleteCentro(centro)} type="button" class="btn btn-danger">Apagar</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>
      <InfoModal show={showInfoModal} setShow={setShowInfoModal} centro={centroSelecionado} />
      <EditModal show={showEditModal} setShow={setShowEditModal} setCentros={setCentros} centro={centroSelecionado} />
      <AddModal show={showAddModal} setShow={setShowAddModal} setCentros={setCentros}/>
    </body>
  );
}