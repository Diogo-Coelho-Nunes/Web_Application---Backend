import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form'

export default function InfoModal(props) {
    const handleClose = () => {
        props.setShow(false)
    };

    if(props.centro == undefined) return
    else return (
        <Modal show={props.show} onHide={handleClose}>
            <Modal.Header closeButton>
                <Modal.Title>{props.centro.Nome_Centro}</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <Form>
                <Form.Group className="text-center">
                <Form.Label className="fw-bold">Nome Centro:</Form.Label>
                <p>{props.centro.Nome_Centro}</p>
                <Form.Label className="fw-bold">Localidade:</Form.Label>
                <p>{props.centro.Localidade}</p>
                <Form.Label className="fw-bold">Código Postal:</Form.Label>
                <p>{props.centro.Código_Postal}</p>
                <Form.Label className="fw-bold">Nome Coordenador:</Form.Label>
                <p>{props.centro.Nome_Coordenador}</p>
                </Form.Group>
                </Form>
            </Modal.Body>
            <Modal.Footer>
                <Button variant="secondary" onClick={handleClose}>
                    Fechar
                </Button>
            </Modal.Footer>
        </Modal>
    );
}