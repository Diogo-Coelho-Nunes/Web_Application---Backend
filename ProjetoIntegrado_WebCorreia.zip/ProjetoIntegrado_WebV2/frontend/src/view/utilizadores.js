import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import axios from "axios";
import React, { useEffect, useState } from "react";
import AddModal from './utilizadoraddmodal';
import EditModal from './utilizadoreditmodal';
import '../css/list.css';
import { useRedirectLogin } from './login';
export default function ListComponent() {

const [utilizadores, setutilizador] = useState([]);
const [showAddModal, setShowAddModal] = React.useState(false)
const [showEditModal, setShowEditModal] = React.useState(false)
const [utilizadorSelecionado, setUtilizadorSelecionado] = React.useState()
useRedirectLogin();

useEffect(() => {
  const url = "https://hidden-lake-88987.herokuapp.com/utilizador/list";
  axios
    .get(url)
    .then((res) => {
      if (res.data.success) {
        const data = res.data.data;
        setutilizador(data);
      } else {
        alert("Error Web Service!");
      }
    })
    .catch((error) => {
      alert(error);
    });
}, []);

const abrirAddUtilizador = (utilizador) => {
    setShowAddModal(true)
  }

const abrirEditUtilizador = (utilizador) => {
    setUtilizadorSelecionado(utilizador)
    setShowEditModal(true)
  }

  const deleteUtilizador = utilizador => {
    const url = 'https://hidden-lake-88987.herokuapp.com/utilizador/delete'

    axios.post(url, {
      N_Utilizador: utilizador.N_Utilizador
    }).then(res => {
      if (res.data.success) {
        setutilizador(utilizadores.filter(u => u.N_Utilizador != utilizador.N_Utilizador))
      } else {
        console.log('Erro a ir buscar data');
      }
    }).catch(error => {
      console.error(error)
    });
  }

function LoadFillData() {
  return utilizadores.map((utilizador, index) => {
    console.log(utilizadores)
    return (
      <tr key={index}>
        <td >{utilizador.NIF}</td>
        <td>{utilizador.Nome_Utilizador}</td>
        <td>{utilizador.Morada}</td>
        <td>{utilizador.Código_Postal}</td>
        <td>{utilizador.N_telemóvel}</td>
        <td>{utilizador.Email}</td>
        <td>{utilizador.Verificado}</td>
        <td>{utilizador.funcao.Descrição}</td>
        <td>{utilizador.centro.Nome_Centro}</td>
        <td>
          <button onClick={() => abrirEditUtilizador(utilizador)} className="btn btn-info ">
            Editar
          </button>
        </td>
        <td>
          <button onClick={() => deleteUtilizador(utilizador)} className="btn btn-danger">Apagar </button>
        </td>
      </tr>
    );
  });
}
    

    return (
      <body>
        <button className="add btn btn-primary" onClick={() => abrirAddUtilizador()}>Adicionar</button>
        <table className="table table-hover table-striped center">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">NIF</th>
                    <th scope="col">Nome</th>
                    <th scope="col">Morada</th>
                    <th scope="col">Código_Postal</th>
                    <th scope="col">Telefone</th>
                    <th scope="col">Email</th>
                    <th scope="col">Verificado</th>
                    <th scope="col">Função</th>
                    <th scope="col">Centro</th>
                </tr>
            </thead>
            <tbody>
            <LoadFillData/>
            </tbody>
            <AddModal show={showAddModal} setShow={setShowAddModal} setutilizador={setutilizador}/>
            <EditModal show={showEditModal} setShow={setShowEditModal} setutilizador={setutilizador} utilizador={utilizadorSelecionado} />
        </table>
        </body>
    );
}