import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "../css/inicio.css";

export default function Login(props) {
const [campemail, setcampemail] = React.useState();
const [camppassword, setcamppassword] = React.useState();
const navigate = useNavigate();

function ONLogin() {
  const baseUrl = "https://damp-badlands-24768.herokuapp.com/utilizador/loginV2";//deve ser/loginV2
  const datapost = {
    Email: campemail,
    Password: camppassword,
  };
  console.log(datapost);
  axios
    .post(baseUrl, datapost)
    .then((response) => {
      if (response.data.success === true) {
        console.log(response.data)
        localStorage.setItem("utilizador", JSON.stringify(response.data.utilizador));
        props.addUser(response.data.utilizador)
        navigate("/centros")
        /* const url = "http://localhost:3000/centro/list";
        axios
          .get(url)
          .then((res) => {
            console.log("Login efetuado");
          })
          .catch((error) => {
            console.error(error);
          }); */
      } else {
        alert("Error");
      }
    })
    .catch((error) => {
      console.log(error)
    });
}



  return (
    
    <div className="Auth-form-container">
      <form className="Auth-form">
        <div className="Auth-form-content">
          <h3 className="Auth-form-title">Log In</h3>
          <div className="form-group mt-3">
            <label>Email address</label>
            <input
              type="email"
              className="form-control mt-1"
              placeholder="Email"
              onChange={(value) => setcampemail(value.target.value)}
            />
          </div>
          <div className="form-group mt-3">
            <label>Password</label>
            <input
              type="password"
              className="form-control mt-1"
              placeholder="Password"
              onChange={(value) => setcamppassword(value.target.value)}
            />
          </div>
          <div className="d-grid gap-2 mt-3">
            <button onClick={ONLogin} type="button" className="btn btn-primary">
              Submit
            </button>
          </div>
          <p className="forgot-password text-center mt-2">
            Efetue login para ter acesso
          </p>
        </div>
      </form>
    </div>
  
  );
};

