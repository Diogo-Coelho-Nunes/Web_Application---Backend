import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import axios from "axios";
import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";

export default function AddModal(props) {
  const [campNIF, setcampNIF] = React.useState();
  const [campNome_Utilizador, setcampNome_Utilizador] = React.useState();
  const [campMorada, setcampMorada] = React.useState();
  const [campCódigo_Postal, setcampCódigo_Postal] = React.useState();
  const [campNtelemovel, setcampNtelemovel] = React.useState();
  const [campEmail, setcampEmail] = React.useState();
  const [campVerificado, setcampVerificado] = React.useState();
  const [stringCentro, setstringCentro] = React.useState();
  const [selectCentro, setselectCentro] = React.useState();
  const [stringFunc, setstringFunc] = React.useState();
  const [selectFunc, setselectFunc] = React.useState();

  const handleClose = () => {
    props.setShow(false);
  };

  function SendSave() {
    if (selectFunc === 0) {
      alert("Escolha uma função!");
    } else if (selectCentro === 0) {
      alert("Escolha um centro!");
    } else if (campNIF === "") {
      alert("Insira um NIF!");
    } else if (campNome_Utilizador === "") {
      alert("Insira um Nome!");
    } else if (campMorada === "") {
      alert("Insira uma morada!");
    } else if (campCódigo_Postal === "") {
      alert("Insira um Código Postal!");
    } else if (campNtelemovel === "") {
      alert("Insira um telemóvel!");
    } else if (campEmail === "") {
      alert("Insira um email!");
    } else {
      const baseUrl = "https://damp-badlands-24768.herokuapp.com/utilizador/create";
      const datapost = {
        NIF: campNIF,
        Nome_Utilizador: campNome_Utilizador,
        Morada: campMorada,
        Código_Postal: campCódigo_Postal,
        N_telemóvel: campNtelemovel,
        Email: campEmail,
        Verificado: campVerificado,
        ID_Funcao: selectFunc,
        N_centro: selectCentro,
      };
      console.log(datapost);
      axios
        .post(baseUrl, datapost)
        .then((response) => {
          if (response.data.success === true) {
            handleClose();
            const url = "https://damp-badlands-24768.herokuapp.com/utilizador/list";
            axios
              .get(url)
              .then((res) => {
                if (res.data.success) {
                  const data = res.data.data;
                  props.setutilizador(data);
                } else {
                  console.log("Erro a ir buscar data");
                }
              })
              .catch((error) => {
                console.error(error);
              });
          } else {
            alert("Error");
          }
        })
        .catch((error) => {
          alert("Error 34 " + error);
        });
    }
  }

  return (
    <Modal show={props.show} onHide={handleClose}>
      <Modal.Header closeButton>
        <Modal.Title>{"Adicionar um utilizador"}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form>
          <Form.Group className="mb-3" controlId="Nome_Centro">
            <Form.Label className="fw-bold">NIF:</Form.Label>
            <Form.Control
              type="text"
              onChange={(value) => setcampNIF(value.target.value)}
            />
          </Form.Group>
          <Form.Group className="mb-3" controlId="Nome_Centro">
            <Form.Label className="fw-bold">Nome:</Form.Label>
            <Form.Control
              type="text"
              onChange={(value) => setcampNome_Utilizador(value.target.value)}
            />
          </Form.Group>
          <Form.Group className="mb-3" controlId="Localidade">
            <Form.Label className="fw-bold">Morada:</Form.Label>
            <Form.Control
              type="text"
              onChange={(value) => setcampMorada(value.target.value)}
            />
          </Form.Group>
          <Form.Group className="mb-3" controlId="codPost">
            <Form.Label className="fw-bold">Código Postal:</Form.Label>
            <Form.Control
              type="text"
              onChange={(value) => setcampCódigo_Postal(value.target.value)}
            />
          </Form.Group>
          <Form.Group className="mb-3" controlId="Nome_Coord">
            <Form.Label className="fw-bold">Numero Telemovel:</Form.Label>
            <Form.Control
              type="text"
              onChange={(value) => setcampNtelemovel(value.target.value)}
            />
          </Form.Group>
          <Form.Group className="mb-3" controlId="Nome_Coord">
            <Form.Label className="fw-bold">Email:</Form.Label>
            <Form.Control
              type="text"
              onChange={(value) => setcampEmail(value.target.value)}
            />
          </Form.Group>
          <Form.Group className="mb-3" controlId="Nome_Coord">
            <Form.Label className="fw-bold">Função:</Form.Label>
            <Form.Select
              aria-label="Default select example"
              onChange={(value) => setselectFunc(value.target.value)}
            >
              <option>Selecione uma Função</option>
              <option value="1">Admin</option>
              <option value="2">Funcionário</option>
              <option value="3">Limpeza</option>
            </Form.Select>
          </Form.Group>
          <Form.Group className="mb-3" controlId="N_Centro">
            <Form.Label className="fw-bold">Centro:</Form.Label>
            <Form.Select
              aria-label="Default select example"
              onChange={(value) => setselectCentro(value.target.value)}
            >
              <option>Selecione um Centro</option>
              <option value="1">Centro Viseu</option>
              <option value="2">Centro Tomar</option>
            </Form.Select>
          </Form.Group>
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={handleClose}>
          Fechar
        </Button>
        <Button variant="primary" onClick={SendSave}>
          Criar
        </Button>
      </Modal.Footer>
    </Modal>
  );
}
