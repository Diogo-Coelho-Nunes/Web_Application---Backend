import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import axios from "axios";
import React, { useEffect, useState } from "react";
import AddModal from "./salaaddmodal";
import EditModal from "./salaeditmodal";
import '../css/list.css';
import { useRedirectLogin } from './login';
export default function ListComponent() {

  const [salas, setsalas] = useState([]);
  const [showAddModal, setShowAddModal] = React.useState(false);
  const [showEditModal, setShowEditModal] = React.useState(false);
  const [salaselecionada, setSalaSelecionada] = React.useState()
  useRedirectLogin();

  useEffect(() => {
    const url = "https://damp-badlands-24768.herokuapp.com/sala/list";
    axios
      .get(url)
      .then((res) => {
        if (res.data.success) {
          const data = res.data.data;
          setsalas(data);
        } else {
          alert("Error Web Service!");
        }
      })
      .catch((error) => {
        alert(error);
      });
  }, []);

  const abrirAddSala = (sala) => {
    setShowAddModal(true);
  };

  const abrirEditSala = (sala) => {
    setSalaSelecionada(sala)
    setShowEditModal(true);
  };

   const deleteSala = sala => {
    const url = 'https://damp-badlands-24768.herokuapp.com/sala/delete'

    axios.post(url, {
      N_Sala: sala.N_Sala
    }).then(res => {
      if (res.data.success) {
        setsalas(salas.filter(c => c.N_Sala != sala.N_Sala))
      } else {
        console.log('Erro a ir buscar data');
      }
    }).catch(error => {
      console.error(error)
    });
  } 

  function LoadFillData() {
    return salas.map((sala, index) => {
      return (
        <tr key={index}>
          <td>{sala.Nome_Sala}</td>
          <td>{sala.Lugares}</td>
          <td>{sala.Lotação_máxima}</td>
          <td>{sala.Tempo_Limpeza}</td>
          <td>{sala.Disponibilidade}</td>
          <td>{sala.centro.Nome_Centro}</td>
          <td>
          <button onClick={() => abrirEditSala(sala)} className="btn btn-info ">
            Editar
          </button>
          </td>
          <td>
            <button onClick={() => deleteSala(sala)} className="btn btn-danger">Apagar </button>
          </td>
        </tr>
      );
    });
  } 

  return (
    <body>
      <button className="add btn btn-primary" onClick={() => abrirAddSala()}>
            Adicionar
          </button>
    <table className="table table-hover table-striped">
      <thead className="thead-dark">
        <tr>
          <th scope="col">Nome</th>
          <th scope="col">Lugares</th>
          <th scope="col">Lotação Máxima</th>
          <th scope="col">Tempo Limpeza</th>
          <th scope="col">Disponibilidade</th>
          <th scope="col">Centro</th>
        </tr>
      </thead>
      <tbody>
        <LoadFillData/>
      </tbody>
      <AddModal show={showAddModal} setShow={setShowAddModal} setsalas={setsalas} />
      <EditModal show={showEditModal} setShow={setShowEditModal} setsalas={setsalas} salas={salaselecionada} />
    </table>
    </body>
  );
}
