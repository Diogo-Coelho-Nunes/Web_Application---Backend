import React, { useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import axios from "axios";

export default function EditModal(props) {
  const [campNomeEdit, setcampNomeEdit] = React.useState();
  const [campNIFEdit, setcampNIFEdit] = React.useState();
  const [campMoradaEdit, setcampMoradaEdit] = React.useState();
  const [campCdPedit, setcampCdPedit] = React.useState();
  const [campNtelEdit, setcampNtelEdit] = React.useState();
  const [campEmailEdit, setcampEmailEdit] = React.useState();
  const [campIDFuncEdit, setcampIDFuncEdit] = React.useState();
  const [campCentroEdit, setcampCentroEdit] = React.useState();
  const baseUrl = "https://damp-badlands-24768.herokuapp.com/";
  const handleClose = () => {
    props.setShow(false);
  };

  useEffect(() => {
    if (props.utilizador) {
      setcampNomeEdit(props.utilizador.Nome_Utilizador);
      setcampNIFEdit(props.utilizador.NIF);
      setcampMoradaEdit(props.utilizador.Morada);
      setcampCdPedit(props.utilizador.Código_Postal);
      setcampNtelEdit(props.utilizador.N_telemóvel);
      setcampEmailEdit(props.utilizador.Email);
      setcampIDFuncEdit(props.utilizador.ID_Funcao);
      setcampCentroEdit(props.utilizador.centro.Nome_Centro);
    }
  }, [props.utilizador]);

  function SendUpdate() {
    // url de backend
    const url = baseUrl + "utilizador/update/" + props.utilizador.N_Utilizador;
    const datapost = {
      Nome_Utilizador: campNomeEdit,
      NIF: campNIFEdit,
      Morada: campMoradaEdit,
      Código_Postal: campCdPedit,
      N_telemóvel: campNtelEdit,
      Email: campEmailEdit,
      ID_Funcao: campIDFuncEdit,
      N_Centro: campCentroEdit
    };
    axios
      .post(url, datapost)
      .then((response) => {
        if (response.data.success === true) {
          console.log(response.data.message);
          handleClose();
          const url = baseUrl + 'utilizador/list';
          axios
            .get(url)
            .then((res) => {
              if (res.data.success) {
                const data = res.data.data;
                props.setutilizador(data);
              } else {
                console.log("Erro a ir buscar data");
              }
            })
            .catch((error) => {
              console.error(error);
            });
        } else {
          alert("Error");
        }
      })
      .catch((error) => {
        alert("Error 34 " + error);
      });
  }
  if (props.utilizador == undefined) return;
  else
    return (
      <Modal show={props.show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>{props.utilizador.Nome_Utilizador}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3" controlId="Nome">
              <Form.Label className="fw-bold">Nome:</Form.Label>
              <Form.Control
                type="text"
                value={campNomeEdit}
                onChange={(value) => setcampNomeEdit(value.target.value)}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="NIF">
              <Form.Label className="fw-bold">NIF:</Form.Label>
              <Form.Control
                type="text"
                value={campNIFEdit}
                onChange={(value) => setcampNIFEdit(value.target.value)}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="Morada">
              <Form.Label className="fw-bold">Morada:</Form.Label>
              <Form.Control
                type="text"
                value={campMoradaEdit}
                onChange={(value) => setcampMoradaEdit(value.target.value)}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="Código_Postal">
              <Form.Label className="fw-bold">Código_Postal:</Form.Label>
              <Form.Control
                type="text"
                value={campCdPedit}
                onChange={(value) => setcampCdPedit(value.target.value)}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="Código_Postal">
              <Form.Label className="fw-bold">Número telemóvel:</Form.Label>
              <Form.Control
                type="text"
                value={campNtelEdit}
                onChange={(value) => setcampNtelEdit(value.target.value)}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="Código_Postal">
              <Form.Label className="fw-bold">Email:</Form.Label>
              <Form.Control
                type="text"
                value={campEmailEdit}
                onChange={(value) => setcampEmailEdit(value.target.value)}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="Nome_Coord">
              <Form.Label className="fw-bold">Função:</Form.Label>
              <Form.Select aria-label="Default select example" onChange={value=> setcampIDFuncEdit(value.target.value)}>
                <option>Selecione uma Função</option> 
                <option value="1">Admin</option>
                <option value="2">Funcionário</option>
                <option value="3">Limpeza</option>
              </Form.Select>
            </Form.Group>
            <Form.Group className="mb-3" controlId="Nome_Coord">
              <Form.Label className="fw-bold">Centro:</Form.Label>
              <Form.Select aria-label="Default select example" onChange={value=> setcampCentroEdit(value.target.value)}>
                <option>Selecione um Centro</option>
                <option value="1">Centro Viseu</option>
                <option value="2">Centro Tomar</option>
              </Form.Select>
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Fechar
          </Button>
          <Button variant="primary" onClick={SendUpdate}>
            Guardar
          </Button>
        </Modal.Footer>
      </Modal>
    );
}
