import { useNavigate } from "react-router-dom";
import React, { useEffect, useState } from "react";

export const useRedirectLogin = () => {
    const navigate = useNavigate();
    const getCurrentUser = () => {
        const utilizadorgravado = localStorage.getItem("utilizador");
        if (utilizadorgravado) {
            console.log(utilizadorgravado)
          return JSON.parse(utilizadorgravado);
        } else {
          return null;
        }
      };
    
      const [currentUser, setcurrentUser] = useState("");
      useEffect(() => {
        const utilizador = getCurrentUser();
        if (utilizador) {
          setcurrentUser(utilizador);
        }else{
            navigate("/");
        }
      }, []);
      return currentUser
}
