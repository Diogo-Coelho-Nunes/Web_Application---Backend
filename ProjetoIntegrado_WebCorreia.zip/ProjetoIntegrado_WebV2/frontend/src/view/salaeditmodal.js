import React, { useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import axios from "axios";

export default function EditModal(props) {
  const [campNomeEdit, setcampNomeEdit] = React.useState();
  const [campLugaresEdit, setcampLugaresEdit] = React.useState();
  const [campLotaçãoEdit, setcampLotaçãoEdit] = React.useState();
  const [campLimpezaEdit, setcampLimpezaEdit] = React.useState();
  const [campDisponibilidadeEdit, setcampDisponibilidadeEdit] = React.useState();
  const [campCentroEdit, setcampCentroEdit] = React.useState();
  const baseUrl = "https://damp-badlands-24768.herokuapp.com/";
  const handleClose = () => {
    props.setShow(false);
  };

  useEffect(() => {
    if (props.salas) {
      setcampNomeEdit(props.salas.Nome_Sala);
      setcampLugaresEdit(props.salas.Lugares);
      setcampLotaçãoEdit(props.salas.Lotação_máxima);
      setcampLimpezaEdit(props.salas.Tempo_Limpeza);
      setcampDisponibilidadeEdit(props.salas.Disponibilidade);
      setcampCentroEdit(props.salas.N_Centro);
    }
  }, [props.salas]);

  function SendUpdate() {
    // url de backend
    const url = baseUrl + "sala/update/" + props.salas.N_Sala;
    const datapost = {
      Nome_Sala: campNomeEdit,
      Lugares: campLugaresEdit,
      Lotação_máxima: campLotaçãoEdit,
      Tempo_Limpeza: campLimpezaEdit,
      Disponibilidade: campDisponibilidadeEdit,
      N_Centro: campCentroEdit
    };
    axios
      .post(url, datapost)
      .then((response) => {
        if (response.data.success === true) {
          console.log(response.data.message);
          handleClose();
          const url = baseUrl + 'sala/list';
          axios
            .get(url)
            .then((res) => {
              if (res.data.success) {
                const data = res.data.data;
                props.setsalas(data);
              } else {
                console.log("Erro a ir buscar data");
              }
            })
            .catch((error) => {
              console.error(error);
            });
        } else {
          alert("Error");
        }
      })
      .catch((error) => {
        alert("Error 34 " + error);
      });
  }

  if (props.salas == undefined) return;
  else
    return (
      <Modal show={props.show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>{props.salas.Nome_Sala}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3" controlId="Nome_Centro">
              <Form.Label className="fw-bold">Nome:</Form.Label>
              <Form.Control
                type="text"
                value={campNomeEdit}
                onChange={(value) => setcampNomeEdit(value.target.value)}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="Localidade">
              <Form.Label className="fw-bold">Lugares:</Form.Label>
              <Form.Control
                type="text"
                value={campLugaresEdit}
                onChange={(value) => setcampLugaresEdit(value.target.value)}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="codPost">
              <Form.Label className="fw-bold">Lotação Máxima:</Form.Label>
              <Form.Control
                type="text"
                value={campLotaçãoEdit}
                onChange={(value) => setcampLotaçãoEdit(value.target.value)}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="Nome_Coord">
              <Form.Label className="fw-bold">Limpeza:</Form.Label>
              <Form.Control
                type="text"
                value={campLimpezaEdit}
                onChange={(value) => setcampLimpezaEdit(value.target.value)}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="Nome_Coord">
              <Form.Label className="fw-bold">Disponibilidade:</Form.Label>
              <Form.Control
                type="text"
                value={campDisponibilidadeEdit}
                onChange={(value) => setcampDisponibilidadeEdit(value.target.value)}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="Nome_Coord">
              <Form.Label className="fw-bold">Centro:</Form.Label>
              <Form.Select aria-label="Default select example" onChange={value=> setcampCentroEdit(value.target.value)}>
                <option>Selecione um Centro</option>
                <option value="1">Centro Viseu</option>
                <option value="2">Centro Tomar</option>
              </Form.Select>
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Fechar
          </Button>
          <Button variant="primary" onClick={SendUpdate}>
            Guardar
          </Button>
        </Modal.Footer>
      </Modal>
    );
}
