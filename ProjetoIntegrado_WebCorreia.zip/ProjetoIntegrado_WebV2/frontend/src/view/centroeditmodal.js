import React, { useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import axios from "axios";

export default function EditModal(props) {
  const [campNomeEdit, setcampNomeEdit] = React.useState();
  const [campLocalEdit, setcampLocalEdit] = React.useState();
  const [campCdPedit, setcampCdPedit] = React.useState();
  const [campNCordEdit, setcampNCordEdit] = React.useState();
  const baseUrl = "https://damp-badlands-24768.herokuapp.com/";
  const handleClose = () => {
    props.setShow(false);
  };

  useEffect(() => {
    if (props.centro) {
      setcampNomeEdit(props.centro.Nome_Centro);
      setcampLocalEdit(props.centro.Localidade);
      setcampCdPedit(props.centro.Código_Postal);
      setcampNCordEdit(props.centro.Nome_Coordenador);
    }
  }, [props.centro]);

  function SendUpdate() {
    // url de backend
    const url = baseUrl + "centro/update/" + props.centro.N_centro;
    const datapost = {
      Nome_Centro: campNomeEdit,
      Localidade: campLocalEdit,
      Código_Postal: campCdPedit,
      Nome_Coordenador: campNCordEdit,
    };
    axios
      .post(url, datapost)
      .then((response) => {
        if (response.data.success === true) {
          console.log(response.data.message);
          handleClose();
          const url = baseUrl + 'centro/list';
          axios
            .get(url)
            .then((res) => {
              if (res.data.success) {
                const data = res.data.data;
                props.setCentros(data);
              } else {
                console.log("Erro a ir buscar data");
              }
            })
            .catch((error) => {
              console.error(error);
            });
        } else {
          alert("Error");
        }
      })
      .catch((error) => {
        alert("Error 34 " + error);
      });
  }

  if (props.centro == undefined) return;
  else
    return (
      <Modal show={props.show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>{props.centro.Nome_Centro}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3" controlId="Nome_Centro">
              <Form.Label className="fw-bold">Nome:</Form.Label>
              <Form.Control
                type="text"
                value={campNomeEdit}
                onChange={(value) => setcampNomeEdit(value.target.value)}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="Localidade">
              <Form.Label className="fw-bold">Localidade:</Form.Label>
              <Form.Control
                type="text"
                value={campLocalEdit}
                onChange={(value) => setcampLocalEdit(value.target.value)}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="codPost">
              <Form.Label className="fw-bold">Código Postal:</Form.Label>
              <Form.Control
                type="text"
                value={campCdPedit}
                onChange={(value) => setcampCdPedit(value.target.value)}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="Nome_Coord">
              <Form.Label className="fw-bold">Nome Coordenador:</Form.Label>
              <Form.Control
                type="text"
                value={campNCordEdit}
                onChange={(value) => setcampNCordEdit(value.target.value)}
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Fechar
          </Button>
          <Button variant="primary" onClick={SendUpdate}>
            Guardar
          </Button>
        </Modal.Footer>
      </Modal>
    );
}
