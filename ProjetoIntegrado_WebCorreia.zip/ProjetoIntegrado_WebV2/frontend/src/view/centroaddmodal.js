import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import axios from "axios";
import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";

export default function AddModal(props) {
  const [campNome, setcampNome] = React.useState();
  const [campLocal, setcampLocal] = React.useState();
  const [campCdP, setcampCdP] = React.useState();
  const [campNCord, setcampNCord] = React.useState();
  const handleClose = () => {
    props.setShow(false);
  };

  function SendSave() {
    if (campNome === "") {
      alert("Escreva um nome!");
    } else if (campLocal === "") {
      alert("Escreva um Local!");
    } else if (campCdP === "") {
      alert("Escreva um Código Postal!");
    } else if (campNCord === "") {
      alert("Escreva um Coordenador!");
    } else {
      const baseUrl = "https://damp-badlands-24768.herokuapp.com/centro/create";
      const datapost = {
        Nome_Centro: campNome,
        Localidade: campLocal,
        Código_Postal: campCdP,
        Nome_Coordenador: campNCord,
      };
      axios
        .post(baseUrl, datapost)
        .then((response) => {
          if (response.data.success === true) {
        handleClose();
        const url = 'https://damp-badlands-24768.herokuapp.com/centro/list';
        axios
          .get(url)
          .then((res) => {
            if (res.data.success) {
              const data = res.data.data;
              props.setCentros(data);
            } else {
              console.log("Erro a ir buscar data");
            }
          })
          .catch((error) => {
            console.error(error);
          });
        } else {
            alert("Error");
          }
        })
        .catch((error) => {
          alert("Error 34 " + error);
        });
    }
  }

  return (
    <Modal show={props.show} onHide={handleClose}>
      <Modal.Header closeButton>
        <Modal.Title>{"Adicionar um Centro"}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form>
          <Form.Group className="mb-3" controlId="Nome_Centro">
            <Form.Label className="fw-bold">Nome:</Form.Label>
            <Form.Control
              type="text" onChange={(value)=> setcampNome(value.target.value)}
            />
          </Form.Group>
          <Form.Group className="mb-3" controlId="Localidade">
            <Form.Label className="fw-bold">Localidade:</Form.Label>
            <Form.Control
              type="text" onChange={(value)=> setcampLocal(value.target.value)} 
            />
          </Form.Group>
          <Form.Group className="mb-3" controlId="codPost">
            <Form.Label className="fw-bold">Código Postal:</Form.Label>
            <Form.Control
              type="text" onChange={(value)=> setcampCdP(value.target.value)}
            />
          </Form.Group>
          <Form.Group className="mb-3" controlId="Nome_Coord">
            <Form.Label className="fw-bold">Nome Coordenador:</Form.Label>
            <Form.Control
              type="text" onChange={(value)=> setcampNCord(value.target.value)}
            />
          </Form.Group>
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={handleClose}>
          Fechar
        </Button>
        <Button variant="primary" onClick={SendSave}>Criar</Button>
      </Modal.Footer>
    </Modal>
  );
}
