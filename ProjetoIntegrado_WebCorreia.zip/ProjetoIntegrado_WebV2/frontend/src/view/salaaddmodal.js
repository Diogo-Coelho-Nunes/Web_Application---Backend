import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import axios from "axios";
import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";

export default function AddModal(props) {
  const [campNome, setcampNome] = React.useState();
  const [campLugares, setcampLugares] = React.useState();
  const [campLotação, setcampLotação] = React.useState();
  const [campLimpeza, setcampLimpeza] = React.useState();
  const [campDisponibilidade, setcampDisponibilidade] = React.useState();
  const [stringCentro, setstringCentro] = React.useState();
  const [selectCentro, setselectCentro] = React.useState();

  const handleClose = () => {
    props.setShow(false);
  };

  function SendSave() {
    if (campNome === "") {
      alert("Escreva um nome!");
    } else if (campLugares === "") {
      alert("Escreva numero de lugares!");
    } else if (campLotação === "") {
      alert("Escreva uma lotação(%)!");
    } else if (campLimpeza === "") {
      alert("Escreva tempo de limpeza!");
    } else if (selectCentro === 0) {
      alert("Escreva um Centro!");
    } else if (campDisponibilidade === "") {
      alert("Escreva a Disponibiliade(L/O)!");
    } else {
      const baseUrl = "https://damp-badlands-24768.herokuapp.com/sala/create";
      const datapost = {
        Nome_Sala: campNome,
        Lugares: campLugares,
        Lotação_máxima: campLotação,
        Tempo_Limpeza: campLimpeza,
        Disponibilidade: campDisponibilidade,
        N_Centro: selectCentro,
      };
      console.log(datapost)
      axios
        .post(baseUrl, datapost)
        .then((response) => {
          if (response.data.success === true) {
            handleClose();
            const url = "https://damp-badlands-24768.herokuapp.com/sala/list";
            axios
              .get(url)
              .then((res) => {
                if (res.data.success) {
                  const data = res.data.data;
                  props.setsalas(data);
                } else {
                  console.log("Erro a ir buscar data");
                }
              })
              .catch((error) => {
                console.error(error);
              });
          } else {
            alert("Error");
          }
        })
        .catch((error) => {
          alert("Error 34 " + error);
        });
    }
  }

  return (
    <Modal show={props.show} onHide={handleClose}>
      <Modal.Header closeButton>
        <Modal.Title>{"Adicionar uma Sala"}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form>
          <Form.Group className="mb-3" controlId="Nome">
            <Form.Label className="fw-bold">Nome:</Form.Label>
            <Form.Control
              type="text"
              onChange={(value) => setcampNome(value.target.value)}
            />
          </Form.Group>
          <Form.Group className="mb-3" controlId="Lugares">
            <Form.Label className="fw-bold">Lugares:</Form.Label>
            <Form.Control
              type="text"
              onChange={(value) => setcampLugares(value.target.value)}
            />
          </Form.Group>
          <Form.Group className="mb-3" controlId="Lot">
            <Form.Label className="fw-bold">Lotação:</Form.Label>
            <Form.Control
              type="text"
              onChange={(value) => setcampLotação(value.target.value)}
            />
          </Form.Group>
          <Form.Group className="mb-3" controlId="Limpeza">
            <Form.Label className="fw-bold">Limpeza:</Form.Label>
            <Form.Control
              type="text"
              onChange={(value) => setcampLimpeza(value.target.value)}
            />
          </Form.Group>
          <Form.Group className="mb-3" controlId="Dispo">
            <Form.Label className="fw-bold">Disponibilidade:</Form.Label>
            <Form.Control
              type="text"
              onChange={(value) => setcampDisponibilidade(value.target.value)}
            />
          </Form.Group>
          <Form.Group className="mb-3" controlId="N_Centro">
            <Form.Label className="fw-bold">Centro:</Form.Label>
            <Form.Select
              aria-label="Default select example"
              onChange={(value) => setselectCentro(value.target.value)}
            >
              <option>Selecione um Centro</option>
              <option value="1">Centro Viseu</option>
              <option value="2">Centro Tomar</option>
            </Form.Select>
          </Form.Group>
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={handleClose}>
          Fechar
        </Button>
        <Button variant="primary" onClick={SendSave}>
          Criar
        </Button>
      </Modal.Footer>
    </Modal>
  );
}
