import { useNavigate } from "react-router-dom" 
import '../css/main.css';

export default function LogOutButton(props) {
    const navigate = useNavigate();
    const onLogOut = () => {localStorage.removeItem("utilizador") 
    navigate("/")
    props.removeUser()
} 
    return( <button onClick={onLogOut} className="log btn btn-primary">Logout</button>)
}