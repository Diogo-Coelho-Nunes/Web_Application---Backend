
//import axios from "axios";
import axios from "axios";
import React, { useEffect, useState } from "react";

export default function ListComponent() {

    const [count, setCount] = React.useState(null)
    
    useEffect(() => {
        const url = "http://localhost:4000/utilizador/chart";
        axios
        .get(url)
          .then((res) => {
           setCount(res.data)
          
          })
          .catch((error) => {
            alert(error);
          });
      }, []);

      if(count == null) {
        return 'Loading'
      }
      return count;
}

/*export default function ListComponent() {

    const [count, setCount] = React.useState(null)

    useEffect(() => {
        const url = "http://localhost:4000/sala/chartAlocada/";
        axios
        .get(url)
          .then((res) => {
           setCount(res.data)
          
          })
          .catch((error) => {
            alert(error);
          });
      }, []);

      if(count == null) {
        return 'Loading'
      }
      return

}*/
