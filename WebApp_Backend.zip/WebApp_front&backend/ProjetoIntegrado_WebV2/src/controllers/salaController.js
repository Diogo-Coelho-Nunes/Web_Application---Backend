// @ts-check
var Sala = require("../model/Sala");
var sequelize = require("../model/database");
var Centro = require("../model/Centro");
var Reserva = require("../model/Reserva");
const { QueryTypes } = require("sequelize");
const { decodeBase64 } = require("bcryptjs");

const controllers = {};

controllers.testedata = async (req, res) => {
  const response = await sequelize
    .sync()
    .then(function () {
      //Criar Salas
      Sala.create({
        Nome_Sala: "Júpiter",
        Lugares: 15,
        Lotacao_maxima: 10,
        Tempo_Limpeza: '00:05',
        Disponibilidade: "L",
        N_centro: 1,
      });

      Sala.create({
        Nome_Sala: "Marte",
        Lugares: 30,
        Lotacao_maxima: 15,
        Tempo_Limpeza: '00:05',
        Disponibilidade: "O",
        N_centro: 2,
      });
      const data = Sala.findAll();
      return data;
    })
    .catch((err) => {
      return err;
    });
  res.json(response);
};

controllers.list = async (req, res) => {
  const data = await Sala.findAll({
    include: [Centro]
  })
    .then(function (data) {
      return data;
    })
    .catch((error) => {
      return error;
    });
  res.json({ success: true, data: data });
};

controllers.create = async (req, res) => {
  const {
    Nome_Sala,
    Lugares,
    Lotacao_maxima,
    Tempo_Limpeza,
    Disponibilidade,
    N_centro,
  } = req.body;
  const data = await Sala.create({
    Nome_Sala: Nome_Sala,
    Lugares: Lugares,
    Lotacao_maxima: Lotacao_maxima,
    Tempo_Limpeza: Tempo_Limpeza,
    Disponibilidade: Disponibilidade,
    N_centro: N_centro,
  })
    .then(function (data) {
      return data;
    })
    .catch((error) => {
      console.log("Erro: " + error);
      return error;
    });
  res.status(200).json({
    success: true,
    message: "Registado",
    data: data,
  });
};

controllers.get = async (req, res) => {
  const { N_Sala } = req.params;
  const data = await Sala.findAll({
    where: { N_Sala: N_Sala },
    include: [Centro],
  })
    .then(function (data) {
      return data;
    })
    .catch((error) => {
      return error;
    });
  res.json({ success: true, data: data });
};

controllers.update = async (req, res) => {
  const { N_Sala } = req.params;
  const { Nome_Sala, Lugares, Lotacao_maxima, Tempo_Limpeza, Disponibilidade } =
    req.body;
  const data = await Sala.update(
    {
      Nome_Sala: Nome_Sala,
      Lugares: Lugares,
      Lotacao_maxima: Lotacao_maxima,
      Tempo_Limpeza: Tempo_Limpeza,
      Disponibilidade: Disponibilidade,
    },
    {
      where: { N_Sala: N_Sala },
    }
  )
    .then(function (data) {
      return data;
    })
    .catch((error) => {
      return error;
    });
  res.json({ success: true, data: data, message: "Updated successful" });
};

controllers.delete = async (req, res) => {
  const { N_Sala } = req.body;
  const del = await Sala.destroy({
    where: { N_Sala: N_Sala },
  });
  res.json({
    success: true,
    deleted: del,
    message: "Deleted successful",
  });
};


//% de salas mais utilizadas face à capacidade
controllers.ChartSalaMaisAlocadaPerc = async (req, res) => {
  const { capacidade } = req.params;
  const data = await sequelize.query(
    `Select "reservas"."N_Sala", "Nome_Sala", "centros"."Nome_Centro", count(*) as ReservaCount from reservas
  left join salas
  on "reservas"."N_Sala" = "salas"."N_Sala" 
  left join centros 
  on "salas"."N_centro" = "centros"."N_centro"
  where "salas"."Lotacao_maxima" = :capacidade
  group by "reservas"."N_Sala", "salas"."Nome_Sala", "centros"."Nome_Centro" order by ReservaCount desc
  limit 3`,
    { replacements: { capacidade: capacidade } }
  );
  res.json({
    success: true,
    //data: data[0].map(v => ([(v.Nome_Sala + '-' + v.Nome_Centro), parseInt( v.reservacount, 10)]))
    data: data[0].map((v) => ({
      reservacount: parseInt(v.reservacount, 10),
      label: v.Nome_Sala + "-" + v.Nome_Centro,
    })),
  });
};

//parametro q vem do select
//include de reservas
//atributes N_sala, sqequelize.fn(count,

controllers.listMobile = async (req, res) => {
  const { N_centro } = req.params;
  const data = await Sala.findAll({
    where: { N_centro: N_centro },// adicionar disponobolidae a "L"
  })
    .then(function (data) {
      return data;
    })
    .catch((error) => {
      return error;
    });
  res.json({ success: true, data: data });
};

controllers.listMobileSalaDisp = async (req, res) => {
  const {N_Sala,Hora_Inicio,Hora_Fim,Data_Reserva} =
    req.params;

  /*SELECT "reservas"."N_Reserva" as "N_Reserva", "reservas"."Data_Reserva" as "Data_Reserva", "reservas"."Hora_Inicio" as "Hora_Inicio",
    "reservas"."Hora_Fim" as,"N_Funcionario","N_Sala", "Tempo_Limpeza"
    FROM reservas JOIN salas ON reservas.N_Sala = salas.N_Sala 
    WHERE "N_Sala"=${reserva.N_Sala} AND ("Hora_Inicio" BETWEEN CONVERT(datetime, ${reserva.Hora_Inicio}) AND DATEADD(MINUTE, "Tempo_Limpeza", CONVERT(datetime, ${reserva.Hora_Fim})) OR DATEADD(MINUTE, "Tempo_Limpeza", CONVERT(datetime, "Hora_Fim")) BETWEEN CONVERT(datetime, ${reserva.Hora_Inicio}) AND DATEADD(MINUTE, "Tempo_Limpeza", CONVERT(datetime, ${reserva.Hora_Fim}))
    OR CONVERT(datetime, ${reserva.Hora_Inicio}) BETWEEN "Hora_Inicio" AND DATEADD(MINUTE, "Tempo_Limpeza", CONVERT(datetime, "Hora_Fim")) OR DATEADD(MINUTE, "Tempo_Limpeza", CONVERT(datetime, ${reserva.Hora_Fim})) BETWEEN "Hora_Inicio" AND DATEADD(MINUTE, "Tempo_Limpeza", CONVERT(datetime, "Hora_Fim")))*/

  /*const ss = `SELECT "reservas"."N_Reserva" as "N_Sala", "reservas"."Data_Reserva" as "Data_Reserva", "reservas"."Hora_Inicio" as "HoraI", "reservas"."Hora_Fim" as "HoraF","reservas"."N_Funcionario" as "N_Utilizador",
    "reservas"."N_Sala" as "N_Sala", "salas"."Tempo_Limpeza" as "Tempo_Limpeza"
    FROM "reservas" JOIN "salas" ON "reservas"."N_Sala" = "salas"."N_Sala" 
    WHERE "reservas"."N_Sala"=${reserva.N_Sala} AND ("Hora_Inicio" BETWEEN CONVERT(datetime, ${reserva.Hora_Inicio}) AND DATEADD(MINUTE, "Tempo_Limpeza", CONVERT(datetime, ${reserva.Hora_Fim})) OR DATEADD(MINUTE, "Tempo_Limpeza", CONVERT(datetime, "Hora_Fim")) BETWEEN CONVERT(datetime, ${reserva.Hora_Inicio}) AND DATEADD(MINUTE, "Tempo_Limpeza", CONVERT(datetime, ${reserva.Hora_Fim}))
    OR CONVERT(datetime, ${reserva.Hora_Inicio}) BETWEEN "Hora_Inicio" AND DATEADD(MINUTE, "Tempo_Limpeza", CONVERT(datetime, "Hora_Fim")) OR DATEADD(MINUTE, "Tempo_Limpeza", CONVERT(datetime, ${reserva.Hora_Fim})) BETWEEN "Hora_Inicio" AND DATEADD(MINUTE, "Tempo_Limpeza", CONVERT(datetime, "Hora_Fim")))`;*/

  /*const ss = `Select "salas"."N_Sala" as "N_Sala", "salas"."Nome_Sala" as "Nome_Sala",
    "salas"."Lugares" as "Lugares", "salas"."Lotacao_maxima" as "Lotacao_maxima",
    "salas"."Tempo_Limpeza" as "Tempo_Limpeza",
    cast(cast('${Hora_Fim}' as interval) as time) + "salas"."Tempo_Limpeza"*60::text::interval::time as "Tempo_Final",
    "reservas"."N_Reserva" as "N_Reserva"
    From "salas" left join "reservas" on "salas"."N_Sala" = "reservas"."N_Reserva"
    And "reservas"."Data_Reserva" = '${Data_Reserva}'
    And "reservas"."Hora_Fim" > '${Hora_Inicio}'
    And "reservas"."Hora_Inicio" < cast(cast('${Hora_Fim}' as interval) as time) + "salas"."Tempo_Limpeza"*60::text::interval::time
    Where "salas"."N_centro" = '${N_centro}'
    And "salas"."Lotacao_maxima" >= '${N_Participantes}'`;*/

    /*const data2 = await sequelize.query(
      `SELECT "reservas"."N_Reserva" as "N_Reserva", "reservas"."Data_Reserva" as "Data_Reserva", "reservas"."Hora_Inicio" as "Hora_Inicio",
    "reservas"."Hora_Fim" as "Hora_Fim","N_Funcionario","N_Sala", "Tempo_Limpeza"
    FROM reservas JOIN salas ON reservas.N_Sala = salas.N_Sala 
    WHERE "N_Sala" = :N_Sala} AND ("Hora_Inicio" BETWEEN CONVERT(datetime, "reservas"."Hora_Inicio" = :Hora_Inicio) AND DATEADD(MINUTE, "Tempo_Limpeza", CONVERT(datetime, "reservas"."Hora_Fim"= :Hora_Fim) OR DATEADD(MINUTE, "Tempo_Limpeza", CONVERT(datetime, "Hora_Fim")) BETWEEN CONVERT(datetime, "reservas"."Hora_Inicio"= :Hora_Inicio) AND DATEADD(MINUTE, "Tempo_Limpeza", CONVERT(datetime, "reservas"."Hora_Fim"= :Hora_Fim))
    OR CONVERT(datetime, "reservas"."Hora_Inicio"= :Hora_Inicio) BETWEEN "Hora_Inicio" AND DATEADD(MINUTE, "Tempo_Limpeza", CONVERT(datetime, "Hora_Fim")) OR DATEADD(MINUTE, "Tempo_Limpeza", CONVERT(datetime, "reservas"."Hora_Fim"=:Hora_Fim)) BETWEEN "Hora_Inicio" AND DATEADD(MINUTE, "Tempo_Limpeza", CONVERT(datetime, "Hora_Fim"))`,
    
    { replacements: { N_Sala: N_Sala, Hora_Fim: Hora_Fim, Hora_Inicio: Hora_Inicio} }
    )*/
    const data3 = await sequelize.query(
      `SELECT "reservas"."N_Reserva" as "N_Reserva", "reservas"."Data_Reserva" as "Data_Reserva", "reservas"."Hora_Inicio" as "Hora_Inicio",
      "reservas"."Hora_Fim" as "Hora_Fim", "N_Funcionario","salas"."N_Sala", "Tempo_Limpeza", ("reservas"."Hora_Fim" - "reservas"."Hora_Inicio") as "Tempo_Reuniao" 
      FROM reservas JOIN salas ON "reservas"."N_Sala" = "salas"."N_Sala"
    WHERE "salas"."N_Sala" = :N_Sala
    and "reservas"."Data_Reserva" = :Data_Reserva
    and ((:Hora_Inicio <= "reservas"."Hora_Inicio" and :Hora_Fim > ("reservas"."Hora_Fim" + interval '5 minutes')) 
    or ("reservas"."Hora_Inicio" <= :Hora_Inicio and :Hora_Fim < ("reservas"."Hora_Fim" + interval '5 minutes'))  
    or ("reservas"."Hora_Inicio" >= :Hora_Inicio and :Hora_Fim BETWEEN "reservas"."Hora_Inicio" and ("reservas"."Hora_Fim" + interval '5 minutes')) 
    or (("reservas"."Hora_Fim" + interval '5 minutes') <= :Hora_Fim and :Hora_Inicio BETWEEN "reservas"."Hora_Inicio" and ("reservas"."Hora_Fim" + interval '5 minutes')))`,
      { replacements: {N_Sala: N_Sala, Hora_Inicio: Hora_Inicio, Hora_Fim: Hora_Fim, Data_Reserva: Data_Reserva} }
    )
    .then(function (data) {
      return data[0];
    })
    .catch((error) => {
      return error;
    });
  res.json({ success: true, data: data3 });

  /*const toSend = [];
  const data = await sequelize
    .query(ss, { type: QueryTypes.SELECT })
    .then(function (data) {
      data
        .filter((Sala, index) => {
          if (Reserva.N_Sala == null) {
            return true;
          }
          return false;
        })
        .map((Sala, index) => {
          toSend.push(Sala);
        });
      res.json({ success: true, data: toSend });
    })
    .catch((error) => {
      console.log("Erro: " + error);
      return error;
    });*/
};

controllers.salasdisp = async (req, res) => {
  const data = await Sala.findAll({
    where: { Disponibilidade: "L" },
  })
    .then(function (data) {
      return data;
    })
    .catch((error) => {
      return error;
    });
  res.json({ success: true, data: data });
};

controllers.SalaDispHora = async (req, res) => {
  const { Hora_Inicio } = req.params;
  const data = await Sala.findAll({
    where: {
      Disponibilidade: "L",
      Hora_Inicio: Hora_Inicio,
    },
  })
    .then(function (data) {
      return data;
    })
    .catch((error) => {
      return error;
    });
  res.json({ success: true, data: data });
};

module.exports = controllers;
