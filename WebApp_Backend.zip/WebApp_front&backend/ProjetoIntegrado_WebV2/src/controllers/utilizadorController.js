var Utilizador = require('../model/Utilizadores');
var Funcao = require('../model/Funcao');
var sequelize = require('../model/database');
const { verify } = require('jsonwebtoken');
const { sendWelcomeEmail } = require('../services/email');
const nodemailer = require('nodemailer');
const Centro = require('../model/Centro');
var bcrypt = require('bcryptjs');
var salt = bcrypt.genSaltSync(10);

const controllers = {}


controllers.testedata = async(req,res) => {
    const response = await sequelize.sync().then(function() {
        //Criar Utilizadores
        Utilizador.create({
            NIF: 223443332,
            Nome_Utilizador: 'João Santos',
            Morada: 'Rua dos penedros, Viseu',
            Codigo_Postal: '3500-124',
            N_telemovel: 917755635,
            Email:'jsantos99@gmail.com',
            Password: bcrypt.hashSync("1234", salt),
            Verificado: 'R',
            ID_Funcao: 2,
            N_centro: 1

        });

        Utilizador.create({
            NIF: 112223334,
            Nome_Utilizador: 'Maria Costa',
            Morada: 'Av. da  calçada, Coimbra',
            Codigo_Postal: '3545-567',
            N_telemovel: 967473986,
            Email:'mcostas@gmail.com',
            Password: bcrypt.hashSync("1234", salt),
            Verificado: 'R',
            ID_Funcao: 1,
            N_centro: 1

        });
        const data = Utilizador.findAll()
        return data;
    })
    .catch(err => {
        return err;
    });
    res.json(response)
}

controllers.list = async(req, res) => {
    const data = await Utilizador.findAll({
        include: [Funcao, Centro]
    })
    .then(function(data){
        return data;
    })
    .catch(error =>{
        return error;
    });
    res.json({success: true, data: data});
}

controllers.create = async (req, res) => {
    const {NIF,Nome_Utilizador,Morada,Codigo_Postal,N_telemovel,Email,Password,Verificado,ID_Funcao,N_centro} = req.body;
    const data = await Utilizador.create({
        NIF: NIF,
        Nome_Utilizador: Nome_Utilizador,
        Morada: Morada,
        Codigo_Postal: Codigo_Postal,
        N_telemovel: N_telemovel,
        Email: Email,
        Password: bcrypt.hashSync("1234", salt),
        Verificado: Verificado,
        ID_Funcao: ID_Funcao,
        N_centro: N_centro
    })
    .then(function(data) {
        return data;
    })
    .catch(error => {
        console.log("Erro: "+error)
        return error;
    })
    sendWelcomeEmail(data.Email)
    res.status(200).json({
        success: true,
        message:"Registado",
        data: data
    });
    
}

controllers.get = async (req,res) => {
    const {N_Utilizador} = req.params;
    const data = await Utilizador.findAll({
        where: {N_Utilizador: N_Utilizador},
        include: [Funcao],
        include: [Centro]
    })
    .then(function(data){
        return data;
    })
    .catch(error =>{
        return error;
    })
    res.json({ success: true, data: data });
}

controllers.update = async (req,res) => {
    const {N_Utilizador} = req.params;
    const {NIF,Nome_Utilizador,Morada,Codigo_Postal,N_telemovel,Email,Password,Verificado} = req.body;
    const data = await Utilizador.update({
        NIF: NIF,
        Nome_Utilizador: Nome_Utilizador,
        Morada: Morada,
        Codigo_Postal: Codigo_Postal,
        N_telemovel: N_telemovel,
        Email: Email,
        Password: bcrypt.hashSync(Password, salt),
        Verificado: Verificado
    },
    {
        where: {N_Utilizador: N_Utilizador}
    })
    .then( function(data){
        return data;
    })
    .catch(error => {
        return error;
    })
    res.json({success:true, data:data, message:"Updated successful"});
}

controllers.delete = async (req,res) => {
    const {N_Utilizador} = req.body;
    const del = await Utilizador.destroy({
        where: {N_Utilizador: N_Utilizador}
    })
    res.json({success:true,
        deleted:del,
        message:"Deleted successful"
    });
}


//# de utilizadores registados
/*controllers.ChartNUtilizadoresRegistados = async (req,res) => {
    const data = await Utilizador.findAll({atributes: [[sequelize.fn('COUNT', sequelize.col('N_Utilizador')), '#_Utilizadores_Registados']],
    group: ['N_Utilizador'],
})
console.log(data)
.then((data) => {
    data.forEach((element)=> {
        console.log(element.json());
    })
})
.catch(err => {
    return err;
});
}*/

//# de utilizadores registados
controllers.ChartNUtilizadoresRegistados = async (req,res) => {
    const data = await Utilizador.findAndCountAll({
        
    })
    console.log(data.count)
    res.json(data.count)
}

controllers.sendEmail = async (req,res) => {
    const {mail} = req.body;
    const  transporter = nodemailer.createTransport({
        service: 'Hotmail',
          auth: {
            user: 'kleberZimmermann@outlook.pt',
            pass: 'Softinsapassword'
          }
      });
      
      const email = {
        from: 'kleberZimmermann@outlook.pt',
        to: mail,
        subject: 'Gaskammer',
        text: 'Credenciais de acesso',
        html: '<p>Credenciais de acesso</p>'
      
      }
      transporter.sendMail(email, (err, result)=>{
        if(err)
           return console.log(err)
        console.log('Mensagem enviada!' + result)
      })
      res.json({success:true});

}

controllers.login = async (req,res) => {
    if(req.body.Email && req.body.Password) {
        var email = req.body.Email;
        var password = req.body.Password;
    }
    var utilizador = await Utilizador.findOne({where: {Email:email}})
    .then(function(data){
      return data;
      })
      .catch(error =>{
      console.log("Erro: "+error);
      return error;
      })
      if(password === null || typeof password === "undefined") {
          res.status(403).json({
              success: false,
              message: 'Campos em branco'
             
          });
      } else {
          if(req.body.Email && req.body.Password && Utilizador) {
              const isMatch = bcrypt.compareSync(Password, Utilizador.Password);
              if(req.body.Email === Utilizador.Email && isMatch) {
                  let token = jwt.sign({Email: req.body.Email}, config.secret, {expiresIn: '1h'
              });
              res.json({
                  success: true,
                  message: 'Autenticação realizada com sucesso!',
                  token: token
              });
              } else {
                  res.status(403).json({success: false, message: 'Dados de autenticação inválidos.'});     
              }
          } else {
              res.status(400).json({success: false, message: 'Erro no processo de autenticação. Tente de novo mais tarde.'});
          } 
      }
}

controllers.LoginMobile = async (req,res) => {

    if(req.body.Email && req.body.Password) {
        var email = req.body.Email;
        var password = req.body.Password;
    }
    var utilizador = await Utilizador.findOne({where: {Email:email}})
    .then(function(data){
      return data;
      })
      .catch(error =>{
      console.log("Erro: "+error);
      return error;
      })
      if(password === null || typeof password === "undefined") {
          res.status(403).json({
              success: false,
              message: 'Campos em branco'
             
          });
      } else {
          if(req.body.Email && req.body.Password && utilizador) {
              const isMatch = bcrypt.compareSync(password, utilizador.Password);
              if(req.body.Email === utilizador.Email && isMatch) {
              res.json({
                  success: true,
                  message: 'Autenticação realizada com sucesso!',
                  N_Utilizador: utilizador.N_Utilizador
              });
              } else {
                  res.status(403).json({success: false, message: 'Dados de autenticação inválidos.'});     
              }
          } else {
              res.status(400).json({success: false, message: 'Erro no processo de autenticação. Tente de novo mais tarde.'});
          } 
      }
}

controllers.LoginMobileTablet = async (req,res) => {

    if(req.body.Email && req.body.Password) {
        var email = req.body.Email;
        var password = req.body.Password;
    }
    var utilizador = await Utilizador.findOne({where: {Email:email,ID_Funcao: 1}})
    .then(function(data){
      return data;
      })
      .catch(error =>{
      console.log("Erro: "+error);
      return error;
      })
      if(password === null || typeof password === "undefined") {
          res.status(403).json({
              success: false,
              message: 'Campos em branco'
          });
      } else {
          if(req.body.Email && req.body.Password && utilizador) {
              const isMatch = bcrypt.compareSync(password, utilizador.Password);
              if(req.body.Email === utilizador.Email && isMatch) {
                  
              res.json({
                  success: true,
                  message: 'Autenticação realizada com sucesso!',
                  N_Utilizador: utilizador.N_Utilizador
              });
              } else {
                  res.status(403).json({success: false, message: 'Dados de autenticação inválidos.'});     
              }
          } else {
              res.status(400).json({success: false, message: 'Erro no processo de autenticação. Tente de novo mais tarde.'});
          } 
      }


}

//Veio do outro backend

/* controllers.login = async (req,res) => {
    if(req.body.Email && req.body.Password) {
        var email = req.body.Email;
        var password = req.body.Password;
    }
    var utilizador = await Utilizador.findOne({where: {Email:email,ID_Funcao:'1'}})
    .then(function(data){
      return data;
      })
      .catch(error =>{
      console.log("Erro: "+error);
      return error;
      })
      if(password === null || typeof password === "undefined") {
          res.status(403).json({
              success: false,
              message: 'Campos em branco'
             
          });
      } else {
          if(req.body.Email && req.body.Password && Utilizador) {
              const isMatch = bcrypt.compareSync(password, Utilizador.Password);
              if(req.body.Email === Utilizador.Email && isMatch) {
                  let token = jwt.sign({Email: req.body.Email}, config.secret, {expiresIn: '1h'
              });
              res.json({
                  success: true,
                  message: 'Autenticação realizada com sucesso!',
                  token: token
              });
              } else {
                  res.status(403).json({success: false, message: 'Dados de autenticação inválidos.'});     
              }
          } else {
              res.status(400).json({success: false, message: 'Erro no processo de autenticação. Tente de novo mais tarde.'});
          } 
      }
}
 */

controllers.loginV2 = async (req,res) => {
    const {Email,Password} = req.body;

    var utilizador = await Utilizador.findOne({where: {Email:Email,ID_Funcao:'1'}})
    .then(function(data){
      return data;
      })
      .catch(error =>{
      console.log("Erro: "+error);
      return error;
      })
      if(!Password || !Email ) {
          res.status(403).json({
              success: false,
              message: 'Campos em branco'
             
          });
      } else if(!utilizador)
      {
        res.status(403).json({
            success: false,
            message: 'Utilizador não existe'
           
        });
      }
      else {
              const isMatch = bcrypt.compareSync(Password, utilizador.Password);
              if(Email === utilizador.Email && isMatch) {
              res.json({
                  success: true,
                  message: 'Autenticação realizada com sucesso!',
                  utilizador:utilizador
              });
          } else {
              res.status(400).json({success: false, message: 'Erro no processo de autenticação. Tente de novo mais tarde.'});
          } 
      }
}

controllers.updatePassword = async (req,res) => {
    const {N_Utilizador} = req.params;
    const {Password} = req.body;
    const data = await Utilizador.update({
        Password: bcrypt.hashSync(Password, salt),
        Verificado: 'R'
    },
    {
        where: {N_Utilizador: N_Utilizador,Verificado:'NR'}
    })
    .then( function(data){
        return data;
    })
    .catch(error => {
        return error;
    })
    res.json({success:true, data:data, message:"Updated successful"});
}

controllers.updatepass = async (req,res) => {
    const {N_Utilizador} = req.params;
    const {Password} = req.body;
    console.log(N_Utilizador)
    const data = await Utilizador.update({
        Password:bcrypt.hashSync(Password, salt),
        Verificado: 'R'
    },
    {
        where: {N_Utilizador: N_Utilizador}
    })
    .then( function(data){
        return data;
    })
    .catch(error => {
        return error;
    })
    res.json({success:true, data:data, message:"Updated successful"});
}

//teste GitHub

module.exports = controllers