var Centro = require('../model/Centro');
var Sala = require('../model/Sala');
var sequelize = require('../model/database');

const controllers = {}
sequelize.sync()

controllers.testedata = async(req,res) => {
    const response = await sequelize.sync().then(function() {
        //Criar Centros
        Centro.create({
            Nome_Centro: 'Centro de Viseu',
            Localidade: 'Zona Ind. Coimbrões, Viseu',
            Codigo_Postal: '3500-618',
            Nome_Coordenador: 'Tiago Rebelo'

        });
        Centro.create({
            Nome_Centro: 'Centro de Tomar',
            Localidade: 'Av. Dr. Aurélio Ribeiro, Tomar',
            Codigo_Postal: '2300-305',
            Nome_Coordenador: 'Christoph Ribeiro'

        });
        const data = Centro.findAll()
        return data;
    })
    .catch(err => {
        return err;
    });
    res.json(response)
}

controllers.list = async(req, res) => {
    const data = await Centro.findAll({
    })
    .then(function(data){
        return data;
    })
    .catch(error =>{
        return error;
    });
    res.json({success: true, data: data});
}

controllers.create = async (req,res) => {
    const {Nome_Centro, Localidade, Codigo_Postal, Nome_Coordenador} = req.body;
    const data = await Centro.create({
        Nome_Centro: Nome_Centro,
        Localidade: Localidade,
        Codigo_Postal: Codigo_Postal,
        Nome_Coordenador: Nome_Coordenador
    })
    .then(function(data) {
        return data;
    })
    .catch(error => {
        console.log("Erro: "+error)
        return error;
    })
    res.status(200).json({
        success: true,
        message: "Registado",
        data: data
    });
}

controllers.get = async (req, res) => {
    const{N_centro} = req.params;
    const data = await Centro.findAll({
        where: {N_centro: N_centro},
    })
    .then(function(data) {
        return data;
    })
    .catch(error => {
        return error;
    })
    res.json({success: true, data: data});  
}

controllers.update = async (req,res) => {
    const {N_centro} = req.params;
    const {Nome_Centro,Localidade,Codigo_Postal,Nome_Coordenador} = req.body;
    const data = await Centro.update({
        Nome_Centro: Nome_Centro,
        Localidade: Localidade,
        Codigo_Postal: Codigo_Postal,
        Nome_Coordenador: Nome_Coordenador
    },
    {
        where: {N_centro: N_centro}
    })
    .then( function(data){
        return data;
    })
    .catch(error => {
        return error;
    })
    res.json({success:true, data:data, message:"Updated successful"});
        
}

controllers.delete = async (req,res) => {
    const {N_centro} = req.body;
    const del = Centro.destroy({
        where: {N_centro: N_centro}
    })
    res.json({
        success: true,
        deleted: del,
        message: "Deleted Successfully"
    });
}






module.exports = controllers