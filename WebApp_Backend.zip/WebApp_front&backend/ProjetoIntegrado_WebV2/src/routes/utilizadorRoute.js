const express =  require('express');
const router = express.Router();

const utilizadorController = require('../controllers/utilizadorController');
const Utilizador = require('../model/Utilizadores');
const middleware = require('../middleware');

router.get('/testedata',utilizadorController.testedata);
router.get('/list',utilizadorController.list);
router.post('/create',utilizadorController.create);
router.get('/get/:N_Utilizador',utilizadorController.get);
router.put('/update/:N_Utilizador',utilizadorController.update);
router.post('/delete',utilizadorController.delete);
router.get('/chart',utilizadorController.ChartNUtilizadoresRegistados);
router.post('/sendEmail',utilizadorController.sendEmail);
router.post('/login', utilizadorController.login);
router.post('/loginMobile', utilizadorController.LoginMobile);
router.post('/loginMobileTablet', utilizadorController.LoginMobileTablet);
router.put('/updatePassword/:N_Utilizador',utilizadorController.updatePassword);
router.post('/loginV2', utilizadorController.loginV2);
router.post('/updatepass/:N_Utilizador',utilizadorController.updatepass);
module.exports = router