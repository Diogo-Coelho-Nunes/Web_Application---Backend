const express =  require('express');
const router = express.Router();

const reservaController = require('../controllers/reservaController');


router.get('/testedata', reservaController.testedata);
router.get('/get/:N_Reserva', reservaController.get);
router.get('/list', reservaController.list);
router.get('/chart',reservaController.ChartReservasDatas);
router.get('/chartAlocDiaria',reservaController.ChartAlocDiaria);
router.put('/update/:N_Reserva',reservaController.update);
router.delete('/delete/:N_Reserva',reservaController.delete);
router.post('/create',reservaController.create);
router.get('/list/:N_Utilizador',reservaController.listMobile);
router.get('/get/:N_Sala',reservaController.getMobile);
router.delete('/deletePastReserva/:ID_Funcao/:N_Reserva', reservaController.deletePastReserva);
router.get('/listMobileReservasAtuaisFuturas/:N_Utilizador',reservaController.listMobileReservasAtuaisFuturas);


module.exports = router