const express =  require('express');
const { listSalasDisponivel } = require('../controllers/salaController');
const router = express.Router();

const salaController = require ('../controllers/salaController');
const Sala = require('../model/Sala');

router.get('/testedata',salaController.testedata);
router.get('/list',salaController.list);
router.post('/create',salaController.create);
router.get('/get/:N_Sala',salaController.get);
router.post('/update/:N_Sala',salaController.update);
router.post('/delete',salaController.delete);
router.get('/chartAlocada/:capacidade', salaController.ChartSalaMaisAlocadaPerc);
router.get('/list/:N_centro', salaController.listMobile);
router.get('/listsalasD',salaController.salasdisp);
router.get('/listMobileSalaDisp/:N_Sala/:Hora_Inicio/:Hora_Fim/:Data_Reserva',salaController.listMobileSalaDisp);
router.get('/SalaLivreHora/:Hora_Inicio',salaController.SalaDispHora);


module.exports = router