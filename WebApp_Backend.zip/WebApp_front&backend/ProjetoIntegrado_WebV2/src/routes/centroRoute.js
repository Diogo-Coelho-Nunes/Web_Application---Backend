const express =  require('express');
const router = express.Router();
const centroController = require ('../controllers/centroController');


router.get('/testedata',centroController.testedata);
router.get('/list',centroController.list);
router.post('/create',centroController.create);
router.get('/get/:N_centro',centroController.get);
router.post('/update/:N_centro',centroController.update);
router.post('/delete',centroController.delete);

module.exports = router