var Sequelize = require('sequelize');
var sequelize = require('./database');
const Sala = require('./Sala');
var Utilizador = require('./Utilizadores');

var Reserva = sequelize.define('reserva', {
    N_Reserva:{
        primaryKey: true,
        type: Sequelize.INTEGER,
        autoIncrement: true
    },
    Data_Reserva:{
        type: Sequelize.DATEONLY,
        allowNull: false
    },
    Hora_Inicio:{
        type: Sequelize.TIME,
        allowNull: false
    },
    Hora_Fim:{
        type: Sequelize.TIME,
        allowNull: false
    },
    N_Participantes:{
        type: Sequelize.INTEGER,
        allowNull: false
    },
    Titulo_Reserva:{
        type: Sequelize.STRING,
        allowNull: true
    }
    },
    {
        timestamps: false,
    });

    Reserva.belongsTo(Utilizador, {foreignKey:{name: 'N_Funcionario'}});
    Reserva.belongsTo(Sala, {foreignKey:{name: 'N_Sala'}});

    module.exports = Reserva;
