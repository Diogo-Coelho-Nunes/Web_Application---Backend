var Sequelize = require('sequelize');
var sequelize = require('./database');
var Utilizador = require('../model/Utilizadores');


var Centro = sequelize.define('centro', {
    N_centro: {
        primaryKey: true,
        type: Sequelize.INTEGER,
        autoIncrement: true,
    },
    Nome_Centro: {
        type: Sequelize.STRING,
        allowNull: false
    },
    Localidade: {
        type: Sequelize.STRING,
        allowNull: false
    },
    Codigo_Postal:  {
        type: Sequelize.STRING,
        allowNull: false
    },
    Nome_Coordenador:  {
        type: Sequelize.STRING,
        allowNull: false
    },
    },
    {
    timestamps: false,

});

Utilizador.belongsTo(Centro, {foreignKey: { name: 'N_centro'}});

module.exports = Centro
