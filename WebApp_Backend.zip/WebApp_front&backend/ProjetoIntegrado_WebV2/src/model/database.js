var Sequelize = require('sequelize');
const sequelize = new Sequelize(
    'd35ddrr6ftbt5',
    'jfsylrduunoafg',
    'ce9e8abad2ef171f6f512809c1b1bee749baa12ce7b479a568a722a75e250fa6',
    {
        host:'ec2-34-234-240-121.compute-1.amazonaws.com',
        port: '5432',
        dialect: 'postgres',
        dialectOptions: { 
            ssl: { 
            rejectUnauthorized: false 
            } 
            }
    }
);

module.exports = sequelize