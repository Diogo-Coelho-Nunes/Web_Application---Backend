var Sequelize = require('sequelize');
var sequelize = require('./database');
var Utilizador = require('./Utilizadores');

var Funcao = sequelize.define('funcao', {
    ID_Funcao: {
        primaryKey: true,
        type: Sequelize.INTEGER,
        allowNull: false,
        validete:{
            is: 1,
            is: 2,
            is: 3
        },
        defaultValue: 2
    },
    Descricao: {
        type: Sequelize.STRING,
        allowNull: false,
        validete:{
            is: 'Admin',
            is: 'Funcionario',
            is: 'Limpeza'
        },
        defaultValue: 'Funcionario'
    }
    },
    {
        timestamps: false,

});

module.exports = Funcao